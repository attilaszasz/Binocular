# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: source-accessibility.spec.ts >> TR-007 keyboard, honest firmware states and local-only forms: light
- Location: e2e/source-accessibility.spec.ts:26:3

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

# Page snapshot

```yaml
- generic [ref=f1e3]:
  - complementary [ref=f1e4]:
    - generic [ref=f1e5]: Binocular
    - navigation [ref=f1e13]:
      - link "Inventory" [ref=f1e14] [cursor=pointer]:
        - /url: /inventory
      - link "Modules" [ref=f1e18] [cursor=pointer]:
        - /url: /modules
      - link "Logs" [ref=f1e22] [cursor=pointer]:
        - /url: /logs
      - link "Settings" [ref=f1e27] [cursor=pointer]:
        - /url: /settings
    - generic [ref=f1e32]:
      - generic [ref=f1e33]: vdev
      - button "Collapse sidebar" [ref=f1e34]
  - generic [ref=f1e35]:
    - banner [ref=f1e36]:
      - 'button "Theme: light. Click to change." [ref=f1e38]'
    - main [ref=f1e39]:
      - generic [ref=f1e40]:
        - generic [ref=f1e41]:
          - generic [ref=f1e42]:
            - heading "Inventory" [level=1] [ref=f1e43]
            - paragraph [ref=f1e44]: 4 devices • 1 update available • 4 of 4 checked
          - generic [ref=f1e45]:
            - button "Check All" [ref=f1e46]
            - button "Add Device" [ref=f1e47]
        - generic [ref=f1e48]:
          - generic [ref=f1e49]:
            - generic [ref=f1e50]:
              - generic [ref=f1e51]:
                - generic "TR-007 light desktop Unknown" [ref=f1e55]
                - paragraph [ref=f1e56]: ILCE-7CM2
              - generic [ref=f1e57]:
                - button "Check for update" [ref=f1e58]
                - button "Edit device" [ref=f1e59]
                - button "Delete device" [ref=f1e60]
            - generic [ref=f1e61]:
              - status "Firmware status" [ref=f1e62]:
                - generic [ref=f1e63]:
                  - generic [ref=f1e64]: "1.00"
                  - generic [ref=f1e65]: Installed version unknown
              - paragraph [ref=f1e66]: "Last detected version (reference only): 2.01"
              - paragraph [ref=f1e67]: Legacy manual entry · per-model checks
              - paragraph [ref=f1e68]: "Last successfully checked: 10/30/2026, 11:54:45 AM"
          - generic [ref=f1e69]:
            - generic [ref=f1e70]:
              - generic [ref=f1e71]:
                - generic "TR-007 light desktop Update" [ref=f1e75]
                - paragraph [ref=f1e76]: ILCE-7CM2
              - generic [ref=f1e77]:
                - button "Check for update" [ref=f1e78]
                - button "Edit device" [ref=f1e79]
                - button "Delete device" [ref=f1e80]
            - generic [ref=f1e81]:
              - status "Firmware status" [ref=f1e82]:
                - generic [ref=f1e83]:
                  - generic [ref=f1e84]: "Update available:"
                  - generic [ref=f1e85]: "1.00"
                  - generic [ref=f1e88]: "2.01"
              - paragraph [ref=f1e92]: Legacy manual entry · per-model checks
              - paragraph [ref=f1e93]: "Last successfully checked: 10/30/2026, 11:54:45 AM"
              - button "Confirm Update" [ref=f1e94]
          - generic [ref=f1e95]:
            - generic [ref=f1e96]:
              - generic [ref=f1e97]:
                - generic "TR-007 light desktop Current" [ref=f1e101]
                - paragraph [ref=f1e102]: ILCE-7CM2
              - generic [ref=f1e103]:
                - button "Check for update" [ref=f1e104]
                - button "Edit device" [ref=f1e105]
                - button "Delete device" [ref=f1e106]
            - generic [ref=f1e107]:
              - status "Firmware status" [ref=f1e108]:
                - generic [ref=f1e109]:
                  - generic [ref=f1e110]: "2.01"
                  - generic [ref=f1e111]: Latest
              - paragraph [ref=f1e115]: Legacy manual entry · per-model checks
              - paragraph [ref=f1e116]: "Last successfully checked: 10/30/2026, 11:54:46 AM"
          - generic [ref=f1e117]:
            - generic [ref=f1e118]:
              - generic [ref=f1e119]:
                - generic "TR-007 light desktop Incomparable" [ref=f1e123]
                - paragraph [ref=f1e124]: ILCE-7CM2
              - generic [ref=f1e125]:
                - button "Check for update" [ref=f1e126]
                - button "Edit device" [ref=f1e127]
                - button "Delete device" [ref=f1e128]
            - generic [ref=f1e129]:
              - status "Firmware status" [ref=f1e130]:
                - generic [ref=f1e131]:
                  - generic [ref=f1e132]: operator text
                  - generic [ref=f1e133]: Versions cannot be compared
              - paragraph [ref=f1e134]: "Last detected version (reference only): 2.01"
              - paragraph [ref=f1e135]: Legacy manual entry · per-model checks
              - paragraph [ref=f1e136]: "Last successfully checked: 10/30/2026, 11:54:47 AM"
```

# Test source

```ts
  60  |       const model = page.getByRole("textbox", { name: "Model", exact: true });
  61  |       const installed = page.getByRole("textbox", { name: "Current Version", exact: true });
  62  |       const unknown = page.getByRole("checkbox", { name: "Installed version unknown", exact: true });
  63  |       await expect(source).toBeEnabled();
  64  |       await name.fill(`${prefix} Unknown`);
  65  |       await expect(name).toHaveValue(`${prefix} Unknown`);
  66  |       await expect(page.getByRole("button", { name: "Add Device", exact: true })).toBeEnabled();
  67  |       await page.getByRole("button", { name: "Add Device", exact: true }).press("Enter");
  68  |       await expect(page.getByRole("alert")).toHaveText("Please select a module.");
  69  |       await audit(page, info, "keyboard-form-error");
  70  |       await source.press("Enter");
  71  |       await expect(page.locator("#device-module")).toHaveAttribute("aria-expanded", "true");
  72  |       await expect(page.getByRole("listbox")).toBeVisible();
  73  |       await page.keyboard.type("Sony");
  74  |       await expect(page.getByRole("option", { name: /Sony Alpha cameras/ })).toBeFocused();
  75  |       await page.keyboard.press("Enter");
  76  |       await expect(source).toContainText("Sony Alpha cameras");
  77  |       await expect(source).toBeFocused();
  78  |       await expect(source).toHaveAttribute("aria-expanded", "false");
  79  |       await expect(model).toHaveAttribute("aria-describedby", "device-model-help");
  80  |       await expect(model).toHaveAccessibleDescription(/ILCE-/);
  81  |       await model.fill("ILCE-7CM2");
  82  |       await installed.fill("1.00");
  83  |       await expect(unknown).not.toBeChecked();
  84  |       await expect(installed).toHaveAccessibleDescription(/blank version is always unknown/);
  85  |       await installed.press("Tab");
  86  |       await expect(unknown).toBeFocused();
  87  |       await page.keyboard.press("Space");
  88  |       await expect(unknown).toBeChecked();
  89  |       await expect(installed).toHaveValue("1.00");
  90  |       await audit(page, info, "keyboard-unknown-form");
  91  |       await page.getByRole("button", { name: "Add Device", exact: true }).press("Enter");
  92  |       await expect(card("Unknown").getByRole("status", { name: "Firmware status" })).toContainText("Installed version unknown");
  93  |       await card("Unknown").getByRole("button", { name: "Edit device" }).press("Enter");
  94  |       await expect(unknown).toBeChecked();
  95  |       await expect(installed).toHaveValue("1.00");
  96  |       await model.fill("local edit without search");
  97  |       await model.fill("ILCE-7CM2");
  98  |       await page.getByRole("button", { name: "Save Changes" }).press("Enter");
  99  |       await expect(name).toHaveCount(0);
  100 |       expect(firmwareActions).toEqual([]);
  101 |       expect(external).toEqual([]);
  102 |       const after = await vendorCount();
  103 |       expect(after).toBe(baseline);
  104 |       const networkPath = info.outputPath("ordinary-form-network.json");
  105 |       await writeFile(networkPath, JSON.stringify({ before: baseline, after, external, firmwareActions }, null, 2));
  106 |       await info.attach("ordinary-form-network", {
  107 |         path: networkPath,
  108 |         contentType: "application/json",
  109 |       });
  110 | 
  111 |       // Explicit V1 search is intentionally separate from ordinary local interaction.
  112 |       await card("Unknown").getByRole("button", { name: "Edit device" }).press("Enter");
  113 |       await page.getByRole("button", { name: "Search Version" }).press("Enter");
  114 |       await expect(page.getByRole("status", { name: "Version search reference" })).toContainText("reference only): 2.01");
  115 |       await expect(installed).toHaveValue("1.00");
  116 |       await expect(unknown).toBeChecked();
  117 |       expect(await vendorCount()).toBeGreaterThan(baseline);
  118 |       await audit(page, info, "explicit-search-reference");
  119 |       await model.fill("near-match unknown");
  120 |       await page.getByRole("button", { name: "Search Version" }).press("Enter");
  121 |       await expect(page.getByRole("alert")).toContainText("product_not_found");
  122 |       await expect(page.getByRole("status", { name: "Version search reference" })).toHaveCount(0);
  123 |       await expect(installed).toHaveValue("1.00");
  124 |       await expect(unknown).toBeChecked();
  125 |       await audit(page, info, "explicit-search-error");
  126 |       await model.fill("ILCE-7CM2");
  127 |       await expect(page.getByRole("alert")).toHaveCount(0);
  128 |       await page.getByRole("button", { name: "Cancel", exact: true }).press("Enter");
  129 | 
  130 |       for (const [label, current_version] of [["Update", "1.00"], ["Current", "2.01"], ["Incomparable", "operator text"]]) {
  131 |         const response = await request.post("/api/v1/devices", { data: {
  132 |           name: `${prefix} ${label}`, model: "ILCE-7CM2", module_id: sony.id,
  133 |           current_version, installed_unknown: false,
  134 |         } });
  135 |         expect(response.ok()).toBe(true);
  136 |       }
  137 |       await page.reload();
  138 |       for (const label of ["Unknown", "Update", "Current", "Incomparable"]) {
  139 |         await card(label).getByRole("button", { name: "Check for update" }).press("Enter");
  140 |         await expect(card(label).getByText(/Last successfully checked:/)).toBeVisible();
  141 |       }
  142 |       for (const [label, text] of [["Unknown", "Installed version unknown"], ["Incomparable", "Versions cannot be compared"], ["Current", "Latest"]]) {
  143 |         await expect(card(label).getByRole("status", { name: "Firmware status" })).toContainText(text);
  144 |         await expect(card(label).getByRole("button", { name: "Confirm Update" })).toHaveCount(0);
  145 |       }
  146 |       for (const label of ["Unknown", "Incomparable"]) {
  147 |         await expect(card(label).getByText("Latest", { exact: true })).toHaveCount(0);
  148 |         await expect(card(label).getByText("Last detected version (reference only): 2.01")).toBeVisible();
  149 |       }
  150 |       await expect(card("Update").getByRole("status", { name: "Firmware status" })).toContainText("1.00");
  151 |       await expect(card("Update").getByRole("status", { name: "Firmware status" })).toContainText("Update available");
  152 |       await expect(card("Update").getByRole("status", { name: "Firmware status" })).toContainText("2.01");
  153 |       await expect(card("Update").getByRole("button", { name: "Confirm Update" })).toBeVisible();
  154 |       await audit(page, info, "honest-inventory-statuses");
  155 | 
  156 |       // An out-of-band check must remain failed after a full reload, without
  157 |       // relying on the card mutation's transient checkError state.
  158 |       const beforeFailure = (await (await request.get("/api/v1/devices")).json())
  159 |         .find((device: { name: string }) => device.name === `${prefix} Current`);
> 160 |       expect((await request.put("/e2e/vendor-failure/true")).ok()).toBe(true);
      |                                                                    ^ Error: expect(received).toBe(expected) // Object.is equality
  161 |       try {
  162 |         const failure = await (await request.post(`/api/v1/checks/device/${beforeFailure.id}`)).json();
  163 |         expect(failure.success).toBe(false);
  164 |         const retained = await (await request.get(`/api/v1/devices/${beforeFailure.id}`)).json();
  165 |         expect(retained.comparison_status).toBe("failed");
  166 |         expect(retained.has_update).toBe(false);
  167 |         expect(retained.last_checked).toBe(beforeFailure.last_checked);
  168 |         expect(retained.last_check_attempt_at).toBe(failure.checked_at);
  169 |         expect(retained.latest_detected_version).toBe(beforeFailure.latest_detected_version);
  170 |         expect(retained.revision).toBe(beforeFailure.revision);
  171 |         await page.reload();
  172 |         await expect(card("Current").getByRole("status", { name: "Firmware status" })).toContainText("Verification failed");
  173 |         await expect(card("Current").getByText("Latest", { exact: true })).toHaveCount(0);
  174 |         await expect(card("Current").getByRole("alert")).toContainText("Last verification failed");
  175 |         await expect(card("Current").getByText(/Last check attempt:/)).toBeVisible();
  176 |         await expect(card("Current").getByText("Last detected version (reference only): 2.01")).toBeVisible();
  177 |         await audit(page, info, "persisted-failure-after-reload");
  178 |       } finally {
  179 |         expect((await request.put("/e2e/vendor-failure/false")).ok()).toBe(true);
  180 |       }
  181 |       expect(external).toEqual([]);
  182 |       expect(pageErrors).toEqual([]);
  183 |     } finally {
  184 |       const devices = await (await request.get("/api/v1/devices")).json();
  185 |       for (const device of devices.filter((device: { name: string }) => device.name.startsWith(prefix))) {
  186 |         expect((await request.delete(`/api/v1/devices/${device.id}`)).ok()).toBe(true);
  187 |       }
  188 |     }
  189 |   });
  190 | 
  191 |   test(`FR-018 rendered WCAG regression: ${theme} navigation and source states`, async ({ page }, info) => {
  192 |     await page.addInitScript(value => localStorage.setItem("binocular-theme", value), theme);
  193 |     // Test-only response projection exercises amber health without changing backend state or semantics.
  194 |     await page.route("**/api/v1/modules", async route => {
  195 |       const response = await route.fetch();
  196 |       const modules = await response.json();
  197 |       for (const module of modules) {
  198 |         if (module.is_official) {
  199 |           module.status = "active";
  200 |           module.consecutive_failures = module.name === "sony_alpha" ? 2 : 0;
  201 |         }
  202 |       }
  203 |       await route.fulfill({ response, json: modules });
  204 |     });
  205 |     await page.goto("/modules");
  206 |     await expect(page.locator("html")).toHaveClass(theme);
  207 |     await expect(page.getByText("Sony Alpha cameras & lenses", { exact: true })).toBeVisible();
  208 |     await expect(page.getByText("2 consecutive failures", { exact: true })).toBeVisible();
  209 |     await expect(page.getByText("Healthy", { exact: true }).first()).toBeVisible();
  210 |     await expect(page.getByText("Official", { exact: true }).first()).toBeVisible();
  211 |     await expect(page.getByText("active", { exact: true }).first()).toBeVisible();
  212 |     for (const name of ["Inventory", "Modules", "Logs", "Settings"]) {
  213 |       const link = page.getByRole("link", { name, exact: true });
  214 |       await expect(link).toBeVisible();
  215 |       await expect(link).toHaveAttribute("aria-label", name);
  216 |     }
  217 |     await expect(page.getByRole("link", { name: "Modules", exact: true })).toHaveAttribute("aria-current", "page");
  218 |     await audit(page, info, "sources");
  219 | 
  220 |     const card = page.locator('[data-slot="card"]').filter({ has: page.getByText("Sony Alpha cameras & lenses", { exact: true }) });
  221 |     await card.getByRole("button", { name: "Inspect linked devices" }).click();
  222 |     await expect(card.getByRole("button", { name: "Refresh linked devices" })).toBeVisible();
  223 |     await card.locator("summary").click();
  224 |     await page.getByRole("button", { name: "Create a Module", exact: true }).click();
  225 |     await expect(page.getByText("STARTER_TEMPLATE.py", { exact: true })).toBeVisible();
  226 |     await audit(page, info, "scope-details-authoring");
  227 |     await page.getByRole("button", { name: "Upload Module", exact: true }).click();
  228 |     await expect(page.getByText(/unsandboxed, user-vetted code/)).toBeVisible();
  229 |     await audit(page, info, "upload-warning");
  230 | 
  231 |     await page.goto("/inventory");
  232 |     await page.getByRole("button", { name: /Add.*Device/i }).first().click();
  233 |     await page.getByLabel("Source", { exact: true }).click();
  234 |     await page.getByRole("option", { name: /Sony Alpha cameras/ }).click();
  235 |     await expect(page.getByLabel("Model", { exact: true })).toHaveAttribute("aria-describedby", "device-model-help");
  236 |     await audit(page, info, "add-source-help");
  237 |   });
  238 | }
  239 | 
```